package status

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"path/filepath"
	"time"
)

// SetupStatus tracks the progress of setup
type SetupStatus struct {
	VMIP           string    `json:"vmIP"`
	StartTime      time.Time `json:"startTime"`
	EndTime        time.Time `json:"endTime"`
	CurrentStep    string    `json:"currentStep"`
	Status         string    `json:"status"`
	Error          string    `json:"error,omitempty"`
	CompletedSteps []string  `json:"completedSteps"`
}

// Save saves the status to a JSON file
func (s *SetupStatus) Save() error {
	filename := filepath.Join("status", fmt.Sprintf("%s.json", s.VMIP))
	data, err := json.MarshalIndent(s, "", "  ")
	if err != nil {
		return fmt.Errorf("failed to marshal status: %v", err)
	}

	return ioutil.WriteFile(filename, data, 0644)
}

// New creates a new SetupStatus instance
func New(ip string) *SetupStatus {
	return &SetupStatus{
		VMIP:        ip,
		StartTime:   time.Now(),
		CurrentStep: "Initializing",
		Status:      "In Progress",
	}
}
