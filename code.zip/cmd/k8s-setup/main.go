package main

import (
	"fmt"
	"os"
	"time"

	"github.com/maarulav/k8s-setup/internal/logger"
	"github.com/maarulav/k8s-setup/internal/status"
	"github.com/maarulav/k8s-setup/pkg/backup"
	"github.com/maarulav/k8s-setup/pkg/config"
	"github.com/maarulav/k8s-setup/pkg/kubernetes"
	"github.com/maarulav/k8s-setup/pkg/monitoring"
	"github.com/maarulav/k8s-setup/pkg/ssh"
)

func main() {
	// Initialize logger
	log := logger.New()

	// Parse command line arguments
	if len(os.Args) < 2 {
		log.Fatal("Usage: ./k8s-setup <config.json> <ip1> <ip2> <ip3> ...")
	}

	// Load configuration
	cfg, err := config.LoadConfig(os.Args[1])
	if err != nil {
		log.Fatalf("Failed to load configuration: %v", err)
	}

	// Get IP addresses from command line arguments
	ips := os.Args[2:]

	// Create status directory
	if err := os.MkdirAll("status", 0755); err != nil {
		log.Fatalf("Failed to create status directory: %v", err)
	}

	// Process each VM
	for _, ip := range ips {
		status := status.New(ip)
		log.SetStatus(status)
		log.Printf("Starting setup for VM %s", ip)

		// Create VM configuration
		vmConfig := config.VMConfig{
			IP:       ip,
			Username: cfg.SSHConfig.Username,
			Password: cfg.SSHConfig.Password,
			KeyFile:  cfg.SSHConfig.KeyFile,
			Timeout:  time.Duration(cfg.SSHConfig.Timeout) * time.Second,
		}

		// Connect to VM
		client, err := ssh.Connect(vmConfig)
		if err != nil {
			status.Status = "Failed"
			status.Error = fmt.Sprintf("SSH connection failed: %v", err)
			status.Save()
			continue
		}
		defer client.Close()

		// Check system requirements
		if err := client.CheckSystemRequirements(); err != nil {
			status.Status = "Failed"
			status.Error = fmt.Sprintf("System requirements check failed: %v", err)
			status.Save()
			continue
		}

		// Setup Kubernetes
		status.CurrentStep = "Setting up Kubernetes"
		if err := kubernetes.Setup(client, cfg); err != nil {
			status.Status = "Failed"
			status.Error = fmt.Sprintf("Kubernetes setup failed: %v", err)
			status.Save()
			continue
		}
		status.CompletedSteps = append(status.CompletedSteps, "kubernetes")

		// Setup monitoring
		status.CurrentStep = "Setting up monitoring"
		if err := monitoring.Setup(client, cfg); err != nil {
			status.Status = "Failed"
			status.Error = fmt.Sprintf("Monitoring setup failed: %v", err)
			status.Save()
			continue
		}
		status.CompletedSteps = append(status.CompletedSteps, "monitoring")

		// Verify setup
		status.CurrentStep = "Verifying setup"
		if err := kubernetes.Verify(client); err != nil {
			status.Status = "Failed"
			status.Error = fmt.Sprintf("Verification failed: %v", err)
			status.Save()
			continue
		}
		status.CompletedSteps = append(status.CompletedSteps, "verification")

		// Create backup
		status.CurrentStep = "Creating backup"
		if err := backup.Create(client); err != nil {
			log.Printf("Warning: Backup creation failed: %v", err)
		} else {
			status.CompletedSteps = append(status.CompletedSteps, "backup")
		}

		status.Status = "Completed"
		status.EndTime = time.Now()
		status.Save()
		log.Printf("Setup completed successfully for VM %s", ip)
	}
}
